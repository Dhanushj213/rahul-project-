//
//  secondViewController.swift
//  calculator
//
//  Created by student on 02/11/23.
//

import UIKit
import AVKit
import Foundation


class secondViewController: UIViewController {
    var player: AVAudioPlayer!
    
    
    @IBAction func funcPlay(_ sender: Any) {
        playSound()
    }
    
    
    @IBAction func funcPauseAudio(_ sender: Any) {
        player.pause()
    }
    
    
    @IBAction func funcReplayAudio(_ sender: Any) {
        player.currentTime = 0
        player.play()
    }
    
    
    @IBAction func playVideo(_ sender: Any) {
        let url1 = Bundle.main.url(forResource: "video", withExtension: "mp4")
        let avPlayer = AVPlayer(url: url1!)
        let avController = AVPlayerViewController()
        avController.player = avPlayer
        present(avController, animated: true)
        {
            avPlayer.play()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    func playSound()
    {
        let url = Bundle.main.url(forResource: "song", withExtension: "mp3")
        
        player = try! AVAudioPlayer(contentsOf: url!)
        player.play()
        
    }
}
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


